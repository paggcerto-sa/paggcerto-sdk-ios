//
//  PaggcertoSDK.h
//  PaggcertoSDK
//
//  Created by Elder Santos on 10/18/18.
//  Copyright © 2018 Paggcerto. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PaggcertoSDK.
FOUNDATION_EXPORT double PaggcertoSDKVersionNumber;

//! Project version string for PaggcertoSDK.
FOUNDATION_EXPORT const unsigned char PaggcertoSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaggcertoSDK/PublicHeader.h>


